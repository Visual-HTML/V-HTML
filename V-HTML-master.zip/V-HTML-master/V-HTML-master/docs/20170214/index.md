Editor Initialisation

* Rather design visual functions
* Editor come altering document to allow getter and setters on current element

[20170214.html](src/20170214.html)

//TODO: a model for current element (act on one) and a selection (act on several)

//TODO: selection of one and multiple elements.
